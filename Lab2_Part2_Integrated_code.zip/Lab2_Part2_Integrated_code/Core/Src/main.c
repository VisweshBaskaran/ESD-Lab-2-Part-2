/*
 *
 * Author: Visweshwaran Baskaran
 *
 * Sources: STM32 GPIO INPUT Configuration by controllerstech.com:
 * 			https://controllerstech.com/stm32-gpio-input-configuration/
 * 			STM32F411xC/E Reference Manual
 *			https://community.st.com/s/article/how-to-generate-a-one-second-interrupt-using-an-stm32-timer
 * 			https://deepbluembedded.com/stm32-timer-interrupt-hal-example-timer-mode-lab/
 * 			https://www.reddit.com/r/stm32/comments/d8zt8a/delaytimer_code_without_hal/
 * 			https://www.st.com/resource/en/reference_manual/rm0383-stm32f411xce-advanced-armbased-32bit-mcus-stmicroelectronics.pdf
 */


#include "stm32f4xx.h"

#define PRESCALE_10KHZ 8399
#define AUTORELOAD_10Hz 999

int BUTTON_FLAG = 0;

void TIM2_IRQHandler(void)  //Timer 2 handler
{
    if (TIM2->SR & TIM_SR_UIF)
    {
        TIM2->SR &= ~TIM_SR_UIF;  		// Clear the interrupt flag

    }
    if ((GPIOA->IDR & 0x1) == 1)
    {
    	BUTTON_FLAG = !BUTTON_FLAG; //Toggling button flag
    }

    if(BUTTON_FLAG == 1)
    {
    	; //do nothing
    }
    else
    {
    	GPIOD->ODR ^= GPIO_ODR_OD14;  		// Toggling the state of LED connected to GPIOD Pin 14 (red)
    	GPIOD->ODR ^= GPIO_ODR_OD12;		// Toggling the state of LED connected to GPIOD Pin 12 (green)
    }
    TIM2->CR1 |= TIM_CR1_CEN; 	  		// Enabling the timer (TIM2)
}


int main(void)
{
    // Enabling peripheral clock for port A and D
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;

    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;  // Enabling Timer 2 clock

    // Configuring PA0 as input with pull-down to prevent it from floating
   GPIOA->MODER &= ~GPIO_MODER_MODE0; 			//Clearing MODE0 to set GPIOA Pin 0  as input
   GPIOA->PUPDR |= GPIO_PUPDR_PUPD0_1; 			//Setting PUPD0_1 as 1


   GPIOD->MODER |= GPIO_MODER_MODE14_0; //Setting MODE14 to set GPIOD Pin 14 as output
   GPIOD->OTYPER &= ~GPIO_OTYPER_OT14; //Enabling push pull to have control over both high and low states through 2 inbuilt transistors
   GPIOD->PUPDR &= ~GPIO_PUPDR_PUPD14; //Disabling PUPDR i.e disabling pull up pull down configs as push pull is enabled

   GPIOD->MODER |= GPIO_MODER_MODE12_0; //Setting MODE12 to set GPIOD Pin 12 as output
   GPIOD->OTYPER &= ~GPIO_OTYPER_OT12;  //Enabling push pull to have control over both high and low states through 2 inbuilt transistors
   GPIOD->PUPDR &= ~GPIO_PUPDR_PUPD12;  //Disabling PUPDR i.e disabling pull up pull down configs as push pull is enabled
   GPIOD->ODR |= GPIO_ODR_OD14;  		// turning on the LED connected to GPIOD Pin 12
   GPIOD->ODR &= ~GPIO_ODR_OD12;			// turning off the LED connected to GPIOD Pin 12

      TIM2->CR1 = 0;  					 // Disabling the timer at startup
    TIM2->PSC = PRESCALE_10KHZ;  					 // Setting the prescaler value to get 10 kHz
    									 // 84MHz/(8399+1) = 10kHz
    TIM2->ARR = AUTORELOAD_270MS;  					 // Setting the auto-reload value to get 270 msec period
    									 // (10 kHz / (999+1) = 10 Hz)
    TIM2->DIER |= TIM_DIER_UIE;  		 // Enabling the update interrupt
    NVIC_EnableIRQ(TIM2_IRQn);  		 // Enabling the TIM2 IRQ in the Nested Vector Interrupt Controller
    NVIC_SetPriority(TIM2_IRQn, 0);  	 // Set the priority of the TIM2 IRQ to 0 (highest)
    TIM2->CR1 |= TIM_CR1_CEN;  			 // Enable the timer (TIM2)

    while (1)
    {
    	asm("NOP"); //Do nothing
    }
}



